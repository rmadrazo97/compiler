package parser;

import compiler.scanner.token;
import java.util.ArrayList;

public class parse_pointer {
    public parse_pointer padre;
    public String type;
    public Block scope;
    public String value;
    public ArrayList<parse_pointer> children = new ArrayList<>();
    
    public parse_pointer(parse_pointer padre, String type, String value){
        this.padre = padre;
        this.type = type;
        this.value = value;
    }
    
}
