package parser;

import java.util.ArrayList;
import static parser.parser3.father;

public class Semantic2 {
    public static int scope = 0;
    
    public static void main(String[] args){
        Block primer_scope = new Block(father);//Guarda el scope inicial (class)
        father.scope = primer_scope;
        System.out.println("\n\n\n\nRESULTADOS SEMANTIC");
        recorrer(father, primer_scope, primer_scope);  
        recorrer_declaraciones(father);
        recorrer_scopes(primer_scope);
        second_pass(father, 0);
        array_int_literal(primer_scope);
        //Rule18(father, primer_scope);
    }

    public static void recorrer(parse_pointer nodo, Block siguiente_scope, Block primer_scope){
        //Revisar Scope 
        Block resultado_revision = check_scope(nodo, siguiente_scope);
        if(resultado_revision != null){
            siguiente_scope = resultado_revision;
        }
        nodo.scope = siguiente_scope;
        
        //---- regla#3
        mainCheck(nodo);
        //---- regla#3-end
        
        //--- regla#6
        methodCallCheck1(nodo,primer_scope);
        //--- regla#6-end
        
        // regla 18 
        if(nodo.value.equals("break") || nodo.value.equals("continue")){
            ArrayList<String> comodin = new ArrayList<>();
            check_break_continue(nodo.scope, comodin);
            if(comodin.size() > 0){
                //System.out.println("OK");
            }else{
                System.out.println("ERROR: break o continue no dentro de un for " + nodo.value);
            }
        }
        
        if(nodo.children.size() > 0){            
            for(int i = 0; i < nodo.children.size(); i++){
                //revisar declaracion de variables 
                
                recorrer(nodo.children.get(i), siguiente_scope, primer_scope);
            }
        }
    }
    
    public static Block check_scope(parse_pointer nodo, Block scope_actual){
        if(nodo.value.equals("block")){
            Block nuevo_scope = new Block(nodo);
            nodo.scope = nuevo_scope;
            nuevo_scope.padre = scope_actual;
            scope_actual.hijos.add(nuevo_scope);
            return nuevo_scope;
        }else{
            return null;
        }
    }

    public static void recorrer_declaraciones(parse_pointer nodo){
        //check var declarations 
        check_var_decl(nodo);
        //check field decl 
        check_field_decl(nodo);
        //check method declarations 
        check_method_decl(nodo);
        
        
        if(nodo.children.size() > 0){
            for(int i = 0; i < nodo.children.size(); i++){
                if(nodo.type != null){
                    nodo.children.get(i).type = nodo.type;
                }
                recorrer_declaraciones(nodo.children.get(i));
            }
        }
    }
    
    public static void check_var_decl(parse_pointer nodo){
        if(nodo.value.equals("var_decl")){
            String tipo = nodo.children.get(0).children.get(0).value;
            ArrayList<String> declaraciones_temp = new ArrayList<>();
            declaraciones_temp.add(tipo);
            for (int i = 1; i < nodo.children.size(); i++) {
                if(nodo.children.get(i).value.equals(",")){
                    nodo.scope.declaraciones.add(declaraciones_temp);
                    declaraciones_temp = new ArrayList<>();
                    declaraciones_temp.add(tipo);
                }else if(nodo.children.get(i).value.equals(";")){
                    nodo.scope.declaraciones.add(declaraciones_temp);
                }else{
                    declaraciones_temp.add(nodo.children.get(i).children.get(0).value);
                }
            }
        }
    }
    
    public static void check_field_decl(parse_pointer nodo){
        if(nodo.value.equals("field_decl")){
            ArrayList<String> declaraciones_temp = new ArrayList<>();
            String type = nodo.children.get(0).children.get(0).value;
            declaraciones_temp.add(type);
            for(int i = 1; i < nodo.children.size(); i++){
                if(nodo.children.get(i).value.equals(",")){
                    nodo.scope.declaraciones.add(declaraciones_temp);
                    declaraciones_temp = new ArrayList<>();
                    declaraciones_temp.add(type);
                }else if(nodo.children.get(i).value.equals(";")){
                    nodo.scope.declaraciones.add(declaraciones_temp);
                }else{
                    if(nodo.children.get(i).value.equals("field_decl_alt")){
                        for(int j = 0; j < nodo.children.get(i).children.size(); j++){
                            if(nodo.children.get(i).children.get(j).value.equals("int_literal")){
                                declaraciones_temp.add(nodo.children.get(i).children.get(j).children.get(0).value);
                            }else if(nodo.children.get(i).children.get(j).type.equals("produccion")){
                                declaraciones_temp.add(nodo.children.get(i).children.get(j).children.get(0).value);
                            }else{
                                declaraciones_temp.add(nodo.children.get(i).children.get(j).value);
                            }
                        }
                    }else{
                        declaraciones_temp.add(nodo.children.get(i).value);
                    }
                }
            }
        }
    }
    
    public static void check_method_decl(parse_pointer nodo){
        if(nodo.value.equals("method_decl")){
            parse_pointer type = nodo.children.get(0);
            parse_pointer hijotipo = nodo.children.get(nodo.children.size() - 1).children.get(0);
            if(type.value.equals("type")){
                hijotipo.scope.type = type.children.get(0).value;
            }else{
                hijotipo.scope.type = type.value;
            }
            for(int i = 0; i < nodo.children.size(); i++){
                if(nodo.children.get(i).value.equals("method_decl_alt")){
                    parse_pointer nuevo = nodo.children.get(i);
                    parse_pointer hijo = nuevo.padre.children.get(nuevo.padre.children.size() - 1).children.get(0);
                    ArrayList<String> declaracion_temp = new ArrayList<>();
                    for(int j = 0; j < nuevo.children.size(); j++){
                        if(nuevo.children.get(j).value.equals(",")){
                            hijo.scope.declaraciones.add(declaracion_temp);
                            declaracion_temp = new ArrayList<>();
                        }else if(j >= (nuevo.children.size() - 1)){
                            declaracion_temp.add(nuevo.children.get(j).children.get(0).value);
                            hijo.scope.declaraciones.add(declaracion_temp);
                            declaracion_temp = new ArrayList<>();
                        }else{
                            declaracion_temp.add(nuevo.children.get(j).children.get(0).value);
                        }
                    }
                }
            }
        }
    }
    
    public static void recorrer_scopes(Block scope_actual){
        //check for unicidad 
        unicidad(scope_actual);
        
        //System.out.println(scope_actual.declaraciones);
        
        if(scope_actual.hijos.size() > 0){
            for(int i = 0; i < scope_actual.hijos.size(); i++){
                recorrer_scopes(scope_actual.hijos.get(i));
            }
        }
    }
    
    public static void second_pass(parse_pointer nodo, int contador){
        //Revisar Scope 
        if(nodo.type.equals("production")){
            if(nodo.value.equals("expr")){
                ArrayList<String> mirar = new ArrayList<>();
                if(contador > 0){
                    if(nodo.padre.children.get(contador - 1).value.equals("assign_op")){
                        String assign_type = recorrer_backward(nodo.scope, nodo.padre.children.get(contador - 2));
                        if(assign_type != null){
                            if(assign_type.equals("int")){
                                mirar.add("int_literal");
                            }else if(assign_type.equals("boolean")){
                                mirar.add("bool_literal");
                            }
                        }else{
                            System.out.println("ERROR: uso de asignacion pero no se ha declarado la variable. VALOR: " + nodo.padre.children.get(contador - 2).children.get(0).children.get(0).value);
                        }
                    }
                }
                ArrayList<String> verificar_cond = new ArrayList<>();
                verificar_expr(nodo, mirar, verificar_cond);
                //ahorita ya sabemos todo lo que esta al lado de expr 
                //hay que recorrer el de mirar para verificar si todo es del mismo 
                boolean continuar = true;
                for(int j = 1; j < mirar.size(); j++){
                    if(!(mirar.get(j).equals(mirar.get(0)))){
                        String error = mirar.get(j);
                        System.out.println("ERROR: uso de diferentes tipos de variable en expr. VALOR: " + error);
                        continuar = false;
                    }
                    
                    if(verificar_cond.size() > 0){
                        if(! mirar.get(j).equals("bool_literal")){
                            System.out.println("ERROR: Boolean no utilizado en cond op o not. ");
                        }
                    }
                }
                if(mirar.size() == 1){
                    if(verificar_cond.size() > 0){
                        if(! mirar.get(0).equals("bool_literal")){
                            System.out.println("ERROR: Boolean no utilizado en cond op o not. ");
                        }
                    }
                }
                
                if(continuar){
                    //System.out.println(mirar.get(0));
                }
            }else if(nodo.value.equals("method_name")){
                check_params(nodo);
            }else if(nodo.value.equals("statement")){
                if(nodo.children.get(0).value.equals("return")){
                    ArrayList<String> tiposreturn = new ArrayList<>();
                    ArrayList<String> tiposreturn2 = new ArrayList<>();
                    if(nodo.children.size() == 2){
                        if(!(nodo.scope.type.equals("void"))){
                            System.out.println("ERROR: method not type void. ");
                        }
                    }else{
                        if(nodo.scope.type.equals("void")){
                            System.out.println("ERROR: method type void returning something.");
                        }else{
                            verificar_expr(nodo.children.get(1), tiposreturn, tiposreturn2);
                            for(int r = 1; r < tiposreturn.size(); r++){
                                if(!(tiposreturn.get(r).equals(tiposreturn.get(0)))){
                                    System.out.println("ERROR: uso de diferentes tipos de variable en expr");
                                }
                            }
                            String tiporeturn = tiposreturn.get(0);
                            if(tiporeturn.equals("int_literal")){
                                tiporeturn = "int";
                            }else if(tiporeturn.equals("bool_literal")){
                                tiporeturn = "boolean";
                            }
                            if(!(tiporeturn.equals(nodo.scope.type))){
                                System.out.println("ERROR: return type does not match declaration");
                            }
                        }
                    }
                }
            }
        }
        
        if(nodo.children.size() > 0){            
            for(int i = 0; i < nodo.children.size(); i++){
                //revisar declaracion de variables 
                second_pass(nodo.children.get(i), i);
            }
        }
    }

    public static void verificar_expr(parse_pointer nodo, ArrayList<String> resultado, ArrayList<String> booleans){
        if(nodo.value.equals("literal")){
            resultado.add(nodo.children.get(0).value);
        }else if(nodo.value.equals("location")){
            String tipo_check = recorrer_backward(nodo.scope, nodo);
            if(tipo_check == null){
                String error = nodo.children.get(0).children.get(0).value;
                System.out.println("ERROR: la variable que se usa no se ha definido. VALOR: " + error);
            }else{
                if(tipo_check.equals("int")){
                    resultado.add("int_literal");
                }else if(tipo_check.equals("boolean")){
                    resultado.add("bool_literal");
                }
            }
        }else if(nodo.value.equals("cond_op") || nodo.value.equals("!")){
            //System.out.println("Hola hola");
            booleans.add("nop");
        }
        
        if(nodo.children.size() > 0){
            for(int i = 0; i < nodo.children.size(); i++){
                verificar_expr(nodo.children.get(i), resultado, booleans);
            }
        }
    }
    
    public static String recorrer_backward(Block scope, parse_pointer nodo){
        parse_pointer valor = nodo.children.get(0).children.get(0);
        if(scope.declaraciones.size() > 0){
            for(int i = 0; i < scope.declaraciones.size(); i++){
                if(valor.value.equals(scope.declaraciones.get(i).get(1))){
                    return scope.declaraciones.get(i).get(0);
                }
            }
        }
        
        if(!(scope.padre.equals(scope))){
            String continuar = recorrer_backward(scope.padre, nodo);
            if(continuar != null){
                return continuar;
            }
        }
        return null;
    }

    public static void array_int_literal(Block scope){
        //revisar en declaraciones
        for(int j = 0; j < scope.declaraciones.size(); j++){
            if(scope.declaraciones.get(j).size() > 2){
                if(!(Integer.parseInt(scope.declaraciones.get(j).get(3)) > 0)){
                    System.out.println("ERROR: Int_Literal en declaracion de arreglo es menor o igual a 0.");
                }
            }
        }
        
        if(scope.hijos.size() > 0){
            for(int i = 0; i < scope.hijos.size(); i++){
                array_int_literal(scope.hijos.get(i));
            }
        }
    }

    public static void check_params(parse_pointer nodo){
        ArrayList<String> verificacion = new ArrayList<>();
        for(int i = 1; i < nodo.padre.children.size(); i++){
            if(nodo.padre.children.get(i).value.equals("expr")){
                ArrayList<String> hola = new  ArrayList<>();
                verificar_expr(nodo.padre.children.get(i), verificacion, hola);
            }
        }
        //System.out.println(verificacion);
        String a_buscar = nodo.children.get(0).children.get(0).value;
        Block scope_utilizar = search_function(a_buscar, father);
        if(scope_utilizar != null){
            for(int k = 0; k < verificacion.size(); k++){
                if(verificacion.get(k).equals("int_literal")){
                    if(scope_utilizar.declaraciones.get(k).get(0).equals("int")){
                        //
                    }else{
                        System.out.println("ERROR: param error");
                    }
                }else if(verificacion.get(k).equals("bool_literal")){
                    if(scope_utilizar.declaraciones.get(k).get(0).equals("boolean")){
                        //
                    }else{
                        System.out.println("ERROR: param error");
                    }
                }
            }
        }else{
            System.out.println("ERROR: no se encontro la funcion.");
        }
    }

    public static Block search_function(String nombre, parse_pointer nodo){
        if(nodo.value.equals("method_decl")){
            String name = nodo.children.get(1).children.get(0).value;
            if(name.equals(nombre)){
                //System.out.println("encontrado");
                return nodo.children.get(nodo.children.size() - 1).children.get(0).scope;
            }
        }
        
        
        if(nodo.children.size() > 0){
            for(int i = 0; i < nodo.children.size(); i++){
                Block resultado = search_function(nombre, nodo.children.get(i));
                if(resultado != null){
                    return resultado;
                }
            }
        }
        return null;
    }

    public static void unicidad(Block scope){
        for(int i = 0; i < scope.declaraciones.size(); i++){
            for(int j = 0; j < scope.declaraciones.size(); j++){
                if(i != j){
                    if(scope.declaraciones.get(i).get(1).equals(scope.declaraciones.get(j).get(1))){
                        System.out.println("ERROR: variables repetidas, valor " + scope.declaraciones.get(i).get(1));
                    }
                }
            }
        }
    }

    public static void mainCheck(parse_pointer nodo){
        if(nodo.value.equals("method_decl")){
            for(int i = 0; i < nodo.children.size(); i++){
                if(nodo.children.get(i).value.equals("id") ){
                    if(nodo.children.get(i).children.get(0).value.equals("main")){
                      if(nodo.children.get(i+2).value.equals("method_decl_alt")){
                        System.out.println("====ERROR METHOD_DECL_ALT despues de main===== "); 
                      }   
                    }
                }
            }
        }
    }

    // methodcall1
    public static void methodCallCheck1(parse_pointer nodo, Block primer_scope){
        
        if(nodo.value.equals("method_call")){
            for(int e = 0; e < nodo.children.size(); e++){
                if(nodo.children.get(e).value.equals("method_name")){
                    if (nodo.children.get(e).children.get(0).children.get(0).value instanceof String){
                        //System.out.println("nombre de la función llamada: "+nodo.children.get(e).children.get(0).children.get(0).value);
                        methodCallCheck2(father, primer_scope, nodo.children.get(e).children.get(0).children.get(0).value);
                    }       
                }
            }
        }
    }
        // methodcall2
    public static void methodCallCheck2(parse_pointer nodo, Block siguiente_scope, String nombreF){
        Block resultado_revision2 = check_scope(nodo, siguiente_scope);
        if(resultado_revision2 != null){
            siguiente_scope = resultado_revision2;
        }
        
        int returnCount = 0;
        if(nodo.value.equals(nombreF)){
            
            if (nodo.padre.padre.value.equals("method_decl")){
                // ##si hay un method_decl con nombre "nombreF"
                
                // ##recorremos los hijos de method_decl buscando un block
                for(int i = 0; i < nodo.padre.padre.children.size(); i++){
                    
                    //System.out.println(nodo.padre.padre.children.get(i).value);
                    
                    if(nodo.padre.padre.children.get(i).value.equals("block")){
                        
                        // ## si hay un bloque listamos sus hijos en busqueda de un no terminal que contenga return
                        
                        for ( int e=0 ; e < nodo.padre.padre.children.get(i).children.size(); e++){
                            // ## hijos de block....
                            //System.out.println("hijo de block:"+nodo.padre.padre.children.get(i).children.get(e).value);
                            
                            // recorremos los hijos de block en busqueda del return
                            
                            for ( int j=0; j < nodo.padre.padre.children.get(i).children.get(e).children.size(); j++){
                                //System.out.println(nodo.padre.padre.children.get(i).children.get(e).children.get(j).value);

                                // ## si el hijo de block es "return" sumamos al returnCount
                                if(nodo.padre.padre.children.get(i).children.get(e).children.get(j).value.equals("return")){
                                    // si hay return sumar al contador
                                    returnCount +=1;
                               
                                } 
                            }
                            

                        }
                    } 
                }

                // ## preguntamos: si no hay un return entonces -> error
                if (returnCount == 1){
                    // pase 
                    
                } else {
                    System.out.println("----- NO HAY 1 RETURN EN LA FUNCION LLAMADA COMO ARGUMENTO ------");
                }
            }    
        }
        if(nodo.children.size() > 0){            
            for(int i = 0; i < nodo.children.size(); i++){
                methodCallCheck2(nodo.children.get(i), siguiente_scope, nombreF);
            }
        }
    }

    public static void Rule18(parse_pointer nodo,Block scope){
        
        for(int i = 0; i<nodo.children.size(); i++){
                //System.out.println(nodo.children.get(i).value);
                
                if(nodo.children.get(i).value.equals("break") || nodo.children.get(i).value.equals("continue")){
                    
                    //System.out.println(nodo.padre.padre.padre.padre.children.get(i).value);         //Aqui llego al for
                    
                    if(nodo.padre.padre.children.get(i).value.equals("for")){           //Si el padre del break o el continue es for, entonces Success!
                    }else if(nodo.padre.padre.children.get(i).value.equals("if") || nodo.padre.padre.children.get(i).value.equals("else")){ //Si hay un else o un if
                        //System.out.println("\n Entro!!!!!!!!!!!!!!!!!!!!!!!!!!! ");
                        System.out.println(nodo.padre.padre.children.get(i).value);
                        System.out.println(nodo.padre.padre.padre.padre.children.get(i).value);
                        if(nodo.padre.padre.padre.padre.children.get(i).value.equals("for")){       //Si el papa de if o el else es un for, entonces success
                            System.out.println("Success!\n");
                        }else{
                            String error2 = nodo.children.get(i).value;
                            System.out.println("\n Error! " + error2 + "  statement must be inside a for loop.\n "); 
                        }
                    }else{
                        String error = nodo.children.get(i).value;
                        System.out.println("\n Error! " + error + "  statement must be inside a for loop.\n ");
                    } 
                }
                
                if(i <= nodo.children.size()-1){
                    Rule18(nodo.children.get(i), scope.padre);
                }
        }    
    }

    public static void check_break_continue(Block scope, ArrayList<String> verificar){
        if(scope.scope_original.padre.children.get(0).value.equals("for")){
            verificar.add("OK");
        }
        
        if(!(scope.padre.equals(scope))){
            check_break_continue(scope.padre, verificar);
        }
    }

}
