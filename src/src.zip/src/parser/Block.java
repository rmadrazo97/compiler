package parser;

import java.util.ArrayList;

public class Block {
    parse_pointer scope_original; 
    Block padre;
    String type;
    ArrayList<Block> hijos;
    ArrayList<ArrayList<String>> declaraciones; 
    ArrayList<String> utilizaciones;
    public Block(parse_pointer bloque){
        this.scope_original = bloque;
        this.padre = this;
        this.hijos = new ArrayList<>();
        this.declaraciones = new ArrayList<>();
        this.utilizaciones = new ArrayList<>();    
    }
}
