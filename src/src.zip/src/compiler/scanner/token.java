package compiler.scanner;
public class token {
    public String type;
    public String value;
    
    public token(String type, String value){
        this.type = type;
        this.value = value;
    }
    
}
